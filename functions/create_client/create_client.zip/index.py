import os
import json
import uuid
import ydb
from datetime import datetime
import traceback

def handler(event, context):
    """
    Yandex Cloud Function handler to create a new client.
    """
    try:
        # Parse request body first
        body = json.loads(event.get('body', '{}'))
        
        # Fields based on schema.yql
        user_id = body.get('user_id')
        full_name = body.get('full_name')
        contact_number = body.get('contact_number')
        passport_number = body.get('passport_number')
        address = body.get('address')  # Optional
        
        required_fields = {
            'user_id': user_id, 
            'full_name': full_name, 
            'contact_number': contact_number, 
            'passport_number': passport_number
        }
        missing_fields = [k for k, v in required_fields.items() if v is None]

        if missing_fields:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': f'Missing required fields: {", ".join(missing_fields)}'})
            }

        # Use metadata authentication (automatic, secure, no manual tokens)
        driver_config = ydb.DriverConfig(
            endpoint=os.environ.get('YDB_ENDPOINT'),
            database=os.environ.get('YDB_DATABASE'),
            credentials=ydb.iam.MetadataUrlCredentials()
        )
        
        driver = ydb.Driver(driver_config)
        driver.wait(fail_fast=True)
        
        # Create session pool
        pool = ydb.SessionPool(driver)
        
        def check_and_create_client(session):
            # Check if client with passport number already exists
            query = """
            DECLARE $passport_number AS Utf8;
            SELECT id FROM clients WHERE passport_number = $passport_number;
            """
            prepared_query = session.prepare(query)
            result_sets = session.transaction().execute(
                prepared_query,
                {'$passport_number': passport_number},
                commit_tx=True
            )
            
            if result_sets[0].rows:
                return {
                    'statusCode': 409,
                    'body': json.dumps({'error': 'Client with this passport number already exists.'})
                }

            # Create new client
            new_client_id = str(uuid.uuid4())
            current_time = datetime.utcnow()
            
            insert_query = """
            DECLARE $id AS Utf8;
            DECLARE $user_id AS Utf8;
            DECLARE $full_name AS Utf8;
            DECLARE $contact_number AS Utf8;
            DECLARE $passport_number AS Utf8;
            DECLARE $address AS Utf8?;
            DECLARE $created_at AS Timestamp;
            DECLARE $updated_at AS Timestamp;
            
            INSERT INTO clients (id, user_id, full_name, contact_number, passport_number, address, created_at, updated_at) 
            VALUES ($id, $user_id, $full_name, $contact_number, $passport_number, $address, $created_at, $updated_at);
            """
            
            prepared_insert = session.prepare(insert_query)
            session.transaction().execute(
                prepared_insert,
                {
                    '$id': new_client_id,
                    '$user_id': user_id,
                    '$full_name': full_name,
                    '$contact_number': contact_number,
                    '$passport_number': passport_number,
                    '$address': address,
                    '$created_at': current_time,
                    '$updated_at': current_time
                },
                commit_tx=True
            )
            
            return {
                'statusCode': 201,
                'body': json.dumps({'id': new_client_id})
            }
        
        # Execute with session pool
        result = pool.retry_operation_sync(check_and_create_client)
        
        # Clean up
        driver.stop()
        
        return result
        
    except Exception as e:
        # Enhanced error handling
        error_traceback = traceback.format_exc()
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': f'An unexpected error occurred: {str(e)}',
                'traceback': error_traceback
            })
        }