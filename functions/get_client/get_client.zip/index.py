import os
import json
import ydb
import traceback
from datetime import datetime

def handler(event, context):
    """
    Yandex Cloud Function handler to retrieve a client by ID.
    """
    try:
        # Extract client ID from path parameters
        path_params = event.get('pathParameters', {})
        client_id = path_params.get('id')
        
        if not client_id:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Client ID is required'})
            }

        # Use metadata authentication (automatic, secure, no manual tokens)
        driver_config = ydb.DriverConfig(
            endpoint=os.environ.get('YDB_ENDPOINT'),
            database=os.environ.get('YDB_DATABASE'),
            credentials=ydb.iam.MetadataUrlCredentials()
        )
        
        driver = ydb.Driver(driver_config)
        driver.wait(fail_fast=True)
        
        # Create session pool
        pool = ydb.SessionPool(driver)
        
        def get_client(session):
            # Get client by ID
            query = """
            DECLARE $client_id AS Utf8;
            SELECT id, user_id, full_name, contact_number, passport_number, address, created_at, updated_at
            FROM clients 
            WHERE id = $client_id;
            """
            prepared_query = session.prepare(query)
            result_sets = session.transaction().execute(
                prepared_query,
                {'$client_id': client_id},
                commit_tx=True
            )
            
            if not result_sets[0].rows:
                return {
                    'statusCode': 404,
                    'body': json.dumps({'error': 'Client not found'})
                }
            
            # Convert result to dictionary
            row = result_sets[0].rows[0]
            
            # Helper function to convert timestamp
            def convert_timestamp(ts):
                if ts is None:
                    return None
                if isinstance(ts, int):
                    # YDB timestamp is in microseconds
                    return datetime.fromtimestamp(ts / 1000000).isoformat()
                elif hasattr(ts, 'isoformat'):
                    return ts.isoformat()
                else:
                    return str(ts)
            
            client_data = {
                'id': row.id,
                'user_id': row.user_id,
                'full_name': row.full_name,
                'contact_number': row.contact_number,
                'passport_number': row.passport_number,
                'address': row.address,
                'created_at': convert_timestamp(row.created_at),
                'updated_at': convert_timestamp(row.updated_at)
            }
            
            return {
                'statusCode': 200,
                'body': json.dumps(client_data)
            }
        
        # Execute with session pool
        result = pool.retry_operation_sync(get_client)
        
        # Clean up
        driver.stop()
        
        return result
        
    except Exception as e:
        # Enhanced error handling
        error_traceback = traceback.format_exc()
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': f'An unexpected error occurred: {str(e)}',
                'traceback': error_traceback
            })
        } 